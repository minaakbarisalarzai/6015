#ifndef cmdline_hpp
#define cmdline_hpp
#include <stdio.h>
void use_arguments(int argc, char* argv[]);
#endif
