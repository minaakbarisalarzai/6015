//
//  cmdline.hpp
//  msdscript
//
//  Created by Mina Akbari on 1/10/24.
//

#ifndef cmdline_hpp
#define cmdline_hpp
#include <stdio.h>


void use_arguments(int argc, char* argv[]);


#endif /* cmdline_hpp */
