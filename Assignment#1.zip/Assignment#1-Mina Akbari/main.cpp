//
//  main.cpp
//  msdscript
//
//  Created by Mina Akbari on 1/10/24.
//
#include "cmdline.hpp"
#include <iostream>

int main(int argc, char* argv[]) {
    use_arguments(argc, argv);
    return 0;
}
